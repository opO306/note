이 프로젝트에는 다음 외부 리소스가 포함되어 있습니다.

1. [shadcn/ui](https://ui.shadcn.com/)의 컴포넌트
   - [MIT 라이선스](https://github.com/shadcn-ui/ui/blob/main/LICENSE.md)에 따라 사용됩니다.

2. [Unsplash](https://unsplash.com)의 사진
   - [Unsplash License](https://unsplash.com/license)에 따라 사용되었습니다.

3. [Lucide](https://lucide.dev) / [lucide-react](https://github.com/lucide-icons/lucide)
   - [ISC License](https://lucide.dev/license) 및 Feather 기반 부분의 MIT License에 따라 사용됩니다.
